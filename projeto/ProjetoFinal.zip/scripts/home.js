window.addEventListener("DOMContentLoaded", async () => {
  const response = await fetch("/controller.php?acao=pegaAnunciantes", {
    credentials: "include",
  });

  console.log("response: < ", response)

  if (response.status === 401) {
    window.location.href = "/login";
  }

  return null;
});
