<?php

function exitWhenNotLoggedIn()
{ 
  session_start();
  if (!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true) {
    header("Content-Type: application/json");
    http_response_code(401);
    echo json_encode(['logado' => false, 'erro' => 'Sessão expirada ou usuário não autenticado']);
    exit();  
  }
}

?>
